# Pelado · aplicación web unificada

Aplicación en español, HTML/CSS/JavaScript, sin compilación ni cuentas de trabajadores. Incluye control diario offline, períodos 21–20, pagos reales, trabajo por horas y análisis de Excel con PDF real. Los originales están intactos en las carpetas 01 y 02 del ZIP; la aplicación final está únicamente en `03_Pelado_Web_UNIFICADO`.

## Abrir la aplicación

1. Extrae **todo** el ZIP.
2. Abre `03_Pelado_Web_UNIFICADO/index.html` en un navegador moderno. No abras el HTML dentro del visor del ZIP.
3. Introduce tu perfil local. El nombre y la edad no crean una cuenta.
4. Usa **Pelado · Control diario** o **Pelado · Excel / PDF**.

Las dependencias están en `vendor/`: no se necesita internet para abrir la copia local, registrar jornadas, leer Excel y generar PDF. En Android algunos gestores abren un HTML como documento aislado sin acceso a sus carpetas; en ese caso publica la carpeta completa como sitio estático HTTPS o sírvela con un servidor estático. No requiere Kotlin, APK ni backend para el control diario.

El almacenamiento de páginas `file://` depende del navegador. Para usarlo de forma habitual y conservar registros entre versiones, conviene un origen HTTPS estable. Un navegador moderno debe admitir localStorage, structuredClone y File.arrayBuffer. No se ha probado físicamente en Android.

## Publicar

Sube el contenido de la carpeta 03 a un alojamiento estático, manteniendo sus subcarpetas. En GitHub Pages puede usarse una rama cuya raíz contenga el contenido de 03. No publiques `.env` con secretos ni configures el servidor para servir archivos privados.

No se realizó una publicación remota: esta entrega es el proyecto descargable solicitado. No necesita npm para usarse. Para actualizar el sitio conserva el mismo protocolo, dominio y puerto si quieres acceder al mismo localStorage. El service worker precarga la aplicación en HTTPS/localhost; espera la primera carga completa con red antes de usarla offline. Al cambiar el código incrementa la versión `CACHE` en `sw.js`. La caché no es un respaldo de los registros.

## Control diario

- Resumen, calendario, historial, ajustes y perfil conservan los componentes visuales originales: burdeos #7A1F3D, rosa, tarjetas, barra inferior y modal. Splash de 3 segundos.
- El selector superior cambia períodos completos. La clave `2026-09` representa **21/09/2026–20/10/2026**.
- Toca cualquier fecha para registrar Trabajé, Día libre o Falté. Se editan/eliminan jornadas desde Historial.
- Ingresa bandejas por categoría y libras totales con decimales. Grande: 15/16/21/26; Mediano: 31/36/41; Pequeño: 51. Otras tallas quedan sin clasificar en el análisis hasta confirmarlas. La categoría adicional tiene nombre configurable, tarifa provisional 0,08 y ninguna talla asignada.
- El turno Noche se marca manualmente. La aplicación no lo infiere de las horas.
- Para trabajo por horas selecciona Sí, escribe inicio/fin y marca explícitamente si termina al día siguiente. Los límites aceptados son 1 minuto–24 horas. Si supera 16 horas pide confirmación. No se descuentan descansos. No existe captura de varios tramos en una jornada: el requisito contempla un tramo.
- Puedes registrar pelado, horas o ambos. La vista separa sus pagos. Referencia 2,01 USD/h; editable. El feriado de horas usa multiplicador **1 provisional**, configurable independientemente del pelado.
- Registra pagos reales para el período visible. Se comparan con la proyección, sin modificar estimaciones ni jornadas.
- Ajustes permite cambiar perfil, tarifas, bono, quincena, faltas y multiplicadores.

## Reglas económicas y recálculo

Por instrucción confirmada de Billy, los valores predeterminados nuevos son Grande **0,11**, Mediano **0,14** y Pequeño **0,22 USD/lb**. Se conservan nocturno +0,01; feriado ×2; falta 32 USD; quincena 241 USD y asistencia 70 USD sin faltas. La categoría adicional sigue provisional a 0,08 USD/lb.

Las tarifas locales ya guardadas se conservan. `pelado_price_overrides_v1` separa personalizaciones locales de los valores predeterminados publicados en `js/variables.js`. Una actualización de ese archivo cambia los predeterminados para usuarios que no los hayan personalizado; no modifica las personalizaciones. Cambiar una tarifa en tu propio localStorage afecta solo a tu dispositivo. Para cambiar valores predeterminados para todos hay que actualizar/publicar la aplicación. El botón Usar tarifas predeterminadas elimina las personalizaciones por categoría, con confirmación.

Para categoría i:

`lb_por_bandeja = libras_totales / suma_de_bandejas`

`lb_i = bandejas_i * lb_por_bandeja`

`precio_i = (tarifa_i + recargo_nocturno_manual) * multiplicador_feriado`

`pago_i = floor((lb_i * precio_i + Number.EPSILON) * 100) / 100`

Se trunca cada categoría antes de sumar, respetando el orden del original. El pago por horas es el truncamiento a centavos de `(minutos / 60) * tarifa_hora * multiplicador_feriado_horas`. La suma combinada también usa truncamiento; si solo existe uno de los componentes se conserva su importe sin truncarlo por segunda vez, evitando pérdidas de centavos por representación binaria.

**Política histórica conservada:** las tarifas, multiplicadores, descuentos, bono y quincena actuales recalculan todo el historial estimado. No hay instantáneas de tarifas por jornada. Cambiar ajustes puede cambiar estimaciones antiguas; los pagos reales permanecen independientes. La proyección aplica el promedio a días posteriores a hoy que no sean libres ni faltas. Los días futuros ya marcados como trabajados son candidatos a proyección, conforme al modelo original. Se corrigió la doble resta de faltas futuras del original.

## Migración y respaldo

Se leen las claves v1 del mismo origen. Antes de migrar se guarda `pelado_migration_backup_v1` con jornadas, perfil, configuración y pagos originales. Las claves antiguas de jornadas/pagos no se sobrescriben. Las jornadas se agrupan por su fecha real en `pelado_periods_v2`, sin cambiarla. El marcador evita repetir la migración.

Un pago antiguo identificado solo por mes no tiene una fecha suficiente para asignarlo automáticamente al período 21–20. Está visible en Ajustes, con botón **Asignar al período visible**. Selecciona antes el período correcto. Si ya existe un pago se suman los importes, previa confirmación. Se conserva la procedencia para impedir asignarlo dos veces. Puedes corregir el total con Registrar pago real.

Duplicados idénticos por fecha se unifican; si hay registros incompatibles para la misma fecha, se conserva el primero y todas las variantes quedan en el respaldo de migración (`conflicts`) para revisión. Ningún archivo original se altera. Estos conflictos no se resuelven por suposición.

Usa **Descargar respaldo JSON** periódicamente. Importar un respaldo valida sus cantidades, fechas y configuración; pide confirmación y descarga primero los datos actuales, después reemplaza los datos Pelado. No fusiona automáticamente respaldos contradictorios. El respaldo contiene información personal; guárdalo de forma privada. La opción Borrar todos los datos elimina también la migración y sus fuentes locales, previa confirmación.

**Borrar los datos del navegador, usar otro navegador o cambiar de origen puede perder o aislar registros.** No existe copia automática en la nube de las jornadas.

## Analizar Excel / PDF

Selecciona o arrastra `.xlsx`, `.xls` o `.csv` (máximo 10 MB). Puedes elegir hoja. Se buscan encabezados por nombre dentro de las primeras 100 filas, admitiendo columnas reordenadas y variantes habituales. Son necesarias Fecha y Libras; los demás campos ausentes se muestran como —. Las fechas de texto admitidas son `AAAA-MM-DD` y `DD/MM/AAAA` o `DD-MM-AAAA`; las fechas numéricas de Excel también se interpretan. No se adivina el formato estadounidense MM/DD/AAAA. Si los encabezados o fechas no se reconocen se explica el problema; no se inventan filas.

KPIs, gráficos de producción/pago y detalle se filtran por empleado, período y búsqueda. La categoría original, código, rendimiento y horarios de origen se conservan en **Ver**. No se calculan pagos ausentes a partir de una tarifa supuesta. Las horas observadas deduplican intervalos idénticos por empleado, código y día para evitar multiplicarlas por cada talla; intervalos parcialmente solapados no se fusionan. Un horario de fin anterior al inicio se interpreta como día siguiente, igual que el prototipo; no es una validación de nómina. Un intervalo igual inicio/fin no se cuenta porque no permite distinguir cero de 24 horas.

El PDF incluye resumen, tabla y gráfico por categoría, detalle filtrado, unidades, encabezados repetidos y paginación. El análisis se guarda con la clave original `peladoClaroData`. El Excel original permanece en memoria; después de recargar hay que volver a seleccionarlo para enviarlo.

## Integración opcional

Lee `docs/SUPABASE.md`. Por defecto no hay conexión remota. El control diario nunca se envía. Supabase se reserva para el archivo Excel mensual y sus metadatos de recepción/seguridad. Las tarifas se configuran y guardan localmente; no hay una tabla remota de precios. El archivo original solo se envía con consentimiento y verificación antiabuso. No se suben PDFs en esta entrega.

## Estructura

- `js/app.js`: control diario e interfaz original ampliada.
- `js/core.js`: períodos, migración, distribución, truncamiento y horas; funciones puras.
- `js/excel.js`: parser, análisis, detalle, PDF y envío voluntario.
- `js/variables.js`: valores predeterminados y claves.
- `js/remote-config.js`: configuración remota **pública**, vacía por defecto.
- `css/`: estilos originales conservados y ampliaciones al final.
- `vendor/`: librerías locales con versiones y licencias.
- `supabase/`: SQL, función protegida, limpieza y ejemplo de entorno servidor.
- `tests/`: pruebas reproducibles, muestras sintéticas y PDF de prueba.
- `docs/`: inventario, pruebas, decisiones y activación de Supabase.

## Pruebas

Consulta `docs/PRUEBAS.md`. Para reproducir con Node >=24.3 (solo desarrollo): `cd tests`, `npm ci`, `npm test`. No se requiere Node ni estas dependencias para ejecutar la aplicación. Los datos de muestra son sintéticos y están rotulados; no contienen registros reales del usuario.
