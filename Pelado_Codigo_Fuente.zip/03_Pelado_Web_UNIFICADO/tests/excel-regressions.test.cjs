const assert=require('node:assert/strict');global.PeladoCore=require('../js/core.js');global.XLSX=require('../vendor/xlsx.full.min.js');const E=require('../js/excel.js');
const headers=['Cod. Empleado','Empleado','Fecha','Producto','Talla Vta','Categoría de Talla','Entrada Songa','Salida Songa','Libras Peladas','Rend. Mensual','Valor Tarifa','Valor Pago'];
const fixture=[['Detalle Pelado'],['Periodo: Septiembre 2026'],[],headers,
 ['A','Empleado de prueba','2026/09/01','Producto sintético','21/25','GRANDE','2026/09/01 22:00:00','2026/09/02 02:00:30',10,'',.11,1.10],
 ['A','Empleado de prueba','2026/09/01','Producto sintético','31/40','MEDIANO','2026/09/01 23:00:00','2026/09/02 03:00:30',5,'',.14,.70],
 ['A','Empleado de prueba','','LIBRES','','','','','','','',12],
 ['A','Empleado de prueba','2026/09/02','HORAS - GRUPOS','','','','','','','',4],
 ['A','Empleado de prueba','','AVANCE 25','','','','','','','',-5],
 ['','TOTAL ==>','','','','','','','','','',12.80]];
const p=E.parseRows(fixture),t=E.totals(p.rows);
assert.equal(p.rows.length,5);assert.equal(p.rows[0].date,'2026-09-01');assert.equal(p.rows[2].date,'');assert.equal(p.rows[2].pounds,null);assert.equal(t.lb,15);assert.equal(t.pay,12.8);assert.equal(p.declaredTotals.length,1);assert.equal(p.declaredPeriod,'Septiembre 2026');
assert(Math.abs(t.hours-(5+30/3600))<1e-8);assert.equal(t.cats.LIBRES.pay,12);assert.equal(t.cats['AVANCE 25'].pay,-5);
assert.deepEqual(E.reconciliation(p.rows,p,p.rows.length),{calculated:12.8,declared:12.8,difference:0});assert.equal(E.reconciliation(p.rows.slice(0,2),p,p.rows.length),null);
console.log('PASS YYYY/MM/DD, conceptos sin fecha/libras, suma de centavos y TOTAL separado.');
console.log('PASS unión de intervalos nocturnos solapados con segundos, sin duplicar horas.');
for(const [size,category]of [['51/60','Pequeño'],['31/40','Mediano'],['31/35','Mediano'],['36/40','Mediano'],['41/50','Mediano'],['16/20','Grande'],['21/25.','Grande'],['26/30','Grande']])assert.equal(E.excelCategory(size,''),category);
assert.equal(E.excelCategory('13/15','GRANDE'),'Grande');assert.equal(E.excelCategory('13/15',''),'Sin clasificar');
console.log('PASS tallas como rangos y categoría del archivo como referencia cuando no hay correspondencia.');
const invalid=E.parseRows([headers,['A','Prueba','2026/02/30','LIBRES','','','','','','','',5]]);assert.equal(invalid.rows[0].date,'');assert(invalid.warnings.some(w=>w.includes('Sin fecha')));
assert.equal(E.parseRows([headers,['A','Prueba','2026/09/01','Ajuste','21','GRANDE','','',-2,'',.11,-.22]]).rows[0].pounds,-2);
console.log('PASS fecha inválida conservada con aviso y cantidades con signo conservadas.');
