# Resultados de pruebas · 14 de octubre de 2026

## Entorno y resultado

Node 24.19.0, jsdom 26.1.0 y dependencias de la aplicación empaquetadas localmente. **37 grupos de comprobaciones aprobados**, incluyendo 500 comparaciones económicas contra la función original. La ejecución y su salida están en `RESULTADOS_PRUEBAS.txt`.

| Área | Evidencia ejecutada | Resultado |
|---|---|---|
| Períodos | Fechas 20/21, diciembre/enero, febrero bisiesto/no bisiesto | Aprobado |
| Migración | Agrupación por fecha, duplicados idénticos y conflictos conservados | Aprobado |
| Compatibilidad económica | 500 entradas contra calculateDay extraída de 01, combinando noches/feriados | Aprobado, importes idénticos |
| Truncamiento | Categorías antes de suma, importes negativos y caso de fracción de centavo | Aprobado |
| Horas | 165 minutos nocturnos, solo horas, mixto y feriado independiente | Aprobado |
| Validaciones | Inicio/fin inválidos, negativo, cero, >24 h | Aprobado |
| Proyecciones | Exclusión única de faltas futuras, período pasado y días restantes | Aprobado |
| Categorías | 51, 31/36/41 y todas las tallas enumeradas restantes | Aprobado |
| Parser | Encabezado fila 4/reordenado, números locales, ausencia de pagos, filas inválidas | Aprobado |
| Formatos | XLSX, XLS BIFF8 y CSV sintéticos escritos/releídos con SheetJS local | Aprobado |
| Fechas Excel | Sistema 1904, seriales y rechazo del ficticio 29/02/1900 | Aprobado |
| Horarios de análisis | Cruce de medianoche y fechas explícitas; intervalos repetidos deduplicados | Aprobado |
| Interfaz DOM | Arranque, migración con claves v1, tarifas personalizadas y perfil editable | Aprobado |
| Pagos | Asignación explícita de pago legado una sola vez y pago real nuevo | Aprobado |
| Jornadas | Solo horas, mixto, editar, falta/bono, día libre, eliminar | Aprobado |
| Navegación | Accesos integrados y barra inferior, visibilidad del período | Aprobado |
| Respaldo | Rechazo de configuración inválida sin alterar datos | Aprobado |
| PDF | Firma `%PDF-`, seis páginas para 110 filas, tablas/paginación | Aprobado |
| PDF visual | Render con Poppler de páginas iniciales y final; texto y disposición inspeccionados | Aprobado |
| Endpoint simulado | Origen, extensión/MIME/firma, consentimiento, CAPTCHA, cuota y nombre UUID | Aprobado |
| Endpoint simulado | Revierte archivo cuando falla metadata; configuración inválida bloquea subida | Aprobado |
| Service worker simulado | 13 recursos existen, limpia solo cachés propias, navegación offline | Aprobado |
| Privacidad caché | No intercepta subida ni API fuera de recursos estáticos | Aprobado |
| Fuentes | Los 12 archivos originales incluidos coinciden byte a byte | Aprobado |

## Hallazgos corregidos durante las pruebas

- Una segunda operación de truncamiento sobre un importe ya truncado podía perder un centavo por precisión binaria. Se conserva el importe único sin truncarlo de nuevo cuando no hay segundo componente.
- La proyección original podía excluir dos veces una falta futura; ahora recorre cada fecha una sola vez.
- La edición de perfil en Ajustes ahora persiste realmente.
- La navegación al control diario actualiza el estado interno, no solo las clases de las vistas.
- Los pagos legados conservan su procedencia dentro del pago destino para impedir duplicación incluso si se interrumpe el guardado del marcador auxiliar.

## Límites, sin afirmaciones de pruebas no realizadas

- **No se ejecutó una inspección visual real de la web en navegador ni en Android.** Se conservaron las reglas responsive originales y se revisaron las ampliaciones de CSS para pantallas pequeñas. Las pruebas jsdom verifican DOM y eventos, pero no calculan layout, overflow real, teclado móvil ni accesibilidad visual. Se requiere comprobar estos aspectos en un móvil antes de usarlo como registro definitivo.
- El modo sin red se probó ejecutando lógica/DOM con fetch bloqueado y service worker con cachés simuladas. No sustituye una prueba real de instalación/recarga offline del navegador.
- No había un archivo Excel real dentro del ZIP recibido. Las muestras de `tests/fixtures/` son sintéticas, no contienen jornadas del usuario. No se reutilizaron otros documentos personales fuera del paquete.
- Supabase no está desplegado: SQL/RLS, almacenamiento privado y CAPTCHA reales no se probaron contra un servicio. El endpoint se evaluó con Deno/red simulados, no en el runtime remoto. Debe completarse el checklist de `SUPABASE.md` antes de activarlo.
- El PDF de prueba es una muestra sintética; no representa un pago real.

## Reproducir

Con Node >=24.3:

```sh
cd 03_Pelado_Web_UNIFICADO/tests
npm ci
npm test
```

El lockfile fija dependencias de pruebas. La aplicación para trabajadores no necesita npm ni Node. La advertencia experimental de Node corresponde a la eliminación de anotaciones TypeScript para probar el endpoint en un entorno simulado; no se usa en el navegador.

Actualización posterior: se verificó además el restablecimiento a 0,11/0,14/0,22 y la separación de personalizaciones locales. La nueva configuración sigue pendiente de publicación por el error 403 de GitHub.

Actualización del recuadro de envío: se comprobaron en DOM la casilla seleccionada por defecto, panel plegado, ausencia de solicitudes al abrir/analizar Excel, bloqueo al desmarcar y mensaje honesto cuando falta endpoint. Cuatro comprobaciones adicionales aprobadas.

Corrección posterior con archivo privado adjunto: se compararon por fila fechas, libras, pagos y categorías con el lector anterior; coincidieron el conteo y los totales de libras, dinero y tiempo. Se comprobó el evento de carga, filtros, PDF y restauración local. Las pruebas sintéticas `excel-regressions.test.cjs` cubren AAAA/MM/DD, filas sin fecha/libras, TOTAL, tallas como rangos, signos y unión de intervalos con segundos. El archivo real y el PDF privado de verificación NO forman parte del repositorio ni de este ZIP.
