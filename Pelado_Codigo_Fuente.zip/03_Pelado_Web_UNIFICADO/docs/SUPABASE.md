# Integración opcional de Supabase

## Estado de esta entrega

Preparada en código, **no desplegada ni conectada a un proyecto real**. No se han consultado ni creado proyectos del usuario. No hay credenciales. El modo local, Excel y PDF funcionan independientemente. Las pruebas del endpoint usan servicios simulados; SQL/RLS, cuotas distribuidas y almacenamiento deben validarse tras el despliegue.

## Separación de datos y permisos

- Las jornadas, perfil, ajustes y pagos reales permanecen en localStorage.
- Bucket `pelado-private`, no público, máximo 10 MB. No se otorgan políticas anónimas de insertar, listar ni descargar.
- El frontend envía el Excel original a `upload-excel`. El endpoint usa el secreto de servidor; nunca se entrega al navegador.
- Extensiones XLSX/XLS/CSV; MIME permitido y firma ZIP/OLE/CSV UTF-8 comprobadas. La firma no sustituye un antivirus: el administrador debe tratar los documentos como no confiables y no ejecutar macros.
- UUID aleatorio como nombre de almacenamiento, sin nombres de empleados en la ruta.
- Consentimiento obligatorio; CAPTCHA de Turnstile con comprobación del hostname, origen exacto y cuotas atómicas persistidas en Postgres (5 intentos/IP/hora y 100 globales/hora). Los valores de cuota son controles operativos iniciales, no reglas de producción.
- IP se transforma en SHA-256 con salt secreto; solo el hash y ventana horaria se guardan. El gateway debe sanitizar `x-forwarded-for`; si se añade un proxy, comprobar que no permite falsificar el primer valor. CORS por sí solo no autentica clientes.
- Los límites fallan cerrados cuando no hay acceso a la base de datos. CAPTCHA y límites se complementan; no aseguran ausencia absoluta de abuso.
- El administrador usa autenticación independiente del trabajador. Solo un JWT con `app_metadata.pelado_admin = true` puede leer/eliminar archivos por la API. Nunca autorizar con `user_metadata`.

## Activar

1. Elige un proyecto Supabase y verifica costes, región y política de privacidad adecuados. No hace falta crear cuentas de trabajadores.
2. Revisa `supabase/schema.sql` y ejecútalo desde SQL Editor en un proyecto dedicado. Incluye bucket, tablas, RLS y RPC de cuotas exclusiva de service_role. El script inicial no es idempotente para las políticas: ejecutarlo una vez; para cambios usa migraciones revisadas. Si el proyecto ya tiene políticas de Storage generales, revisa que ninguna permita acceso público al nuevo bucket.
3. Crea una cuenta independiente de administrador. Establece `app_metadata.pelado_admin` desde una operación de administración confiable; no desde el navegador. Renueva su sesión para actualizar los claims. Los operadores del panel Supabase con acceso al proyecto también pueden consultar Storage y descargar los archivos.
4. Crea un widget Cloudflare Turnstile con el dominio HTTPS exacto. Conserva su clave secreta únicamente en el entorno de Edge Functions.
5. Consulta `supabase --help` y la ayuda de `functions`/`secrets` de la versión instalada antes de ejecutar comandos. Coloca esta carpeta `supabase/` en la raíz del proyecto CLI. Despliega `upload-excel` con `verify_jwt=false` según `config.toml`: el endpoint es anónimo y aplica los controles en código.
6. Configura secretos según `supabase/.env.example`: URL, clave service_role del servidor, origen HTTPS exacto sin barra final, secreto Turnstile, salt aleatorio y retención 1–365 días (90 por defecto). Los secretos se guardan en la configuración del servidor, nunca en Git ni `remote-config.js`. En plataformas donde URL/service_role se inyectan automáticamente, usa esas variables de servidor.
7. Completa `js/remote-config.js` con URL de la función y sitekey **pública** de Turnstile. `retentionDays` debe coincidir con la política del servidor. Estas propiedades sí son públicas; no agregues secretos.
8. Programa diariamente `supabase/cleanup.mjs` en un entorno Node >=20 seguro con las variables servidor URL/service_role. Elimina hasta 100 documentos vencidos por ejecución, luego metadata y contadores de más de dos días. Ejecutar más veces si existe acumulación. No borres objetos directamente de `storage.objects` con SQL; usa Storage API. Verifica y supervisa la tarea antes de anunciar que la retención está activa.
9. Publica la aplicación estática sobre HTTPS. Revisa la política de privacidad y añade el contacto del administrador en la comunicación con trabajadores.

## Administrar archivos

Accede al panel del proyecto con tu cuenta de administrador: Storage → `pelado-private`. La ruta incorpora mes de recepción y UUID. Puedes consultar `pelado_uploads` para identificar recepción, ruta y fecha de expiración; el navegador del trabajador recibe solo el UUID.

Para una herramienta administrativa futura, autentica al administrador separadamente y usa el JWT autorizado por RLS para listar/descargar/generar URLs firmadas de corta vigencia. No publiques una service_role ni una URL de listado en la aplicación de trabajadores. No se construyó un login de trabajador ni un panel administrativo público en esta entrega.

## Tarifas y control diario exclusivamente locales

Por instrucción posterior de Billy, Supabase almacena únicamente el Excel mensual original, más metadatos mínimos de recepción y contadores de seguridad. No hay tabla `pelado_rates` ni consulta de precios remotos. Los predeterminados se publican en `js/variables.js` y las personalizaciones se guardan en el dispositivo. Una edición local no actualiza a otros trabajadores.

## Verificación obligatoria tras despliegue

- Usuario anónimo: listar/descargar/escribir directamente en Storage debe denegarse.
- Usuario autenticado ordinario: lectura también denegada. Administrador autorizado: lectura correcta.
- Archivos inválidos, MIME falso, tamaño >10 MB, falta de consentimiento, CAPTCHA inválido/reutilizado y origen distinto deben rechazarse.
- La sexta tentativa por IP/hora y la tentativa 101 global deben rechazarse (en el entorno de ensayo puede ajustarse la cuota).
- Dos solicitudes simultáneas deben consumir la cuota atómicamente. Revisar logs sin registrar documentos, IP cruda ni secretos.
- Subir un archivo válido, comprobar mismos bytes al descargar como administrador, revisar metadata y eliminarlo.
- Probar limpieza con un documento vencido y verificar desaparición de objeto y metadata.
- Ejecutar asesores de seguridad de Supabase y revisar todas las políticas existentes.

## Fuentes verificadas el 14/10/2026

- https://supabase.com/docs/guides/storage/security/access-control
- https://supabase.com/docs/guides/functions/secrets
- https://supabase.com/docs/guides/functions/function-configuration
- https://supabase.com/changelog.md
- https://supabase.com/changelog/cbc-tls-ciphers-deprecated

El cambio reciente de cifrados TLS afecta a clientes antiguos; se usa HTTPS desde navegadores actuales. No modifica el modelo de permisos descrito aquí. No se verificó un despliegue remoto por falta de configuración de proyecto.
