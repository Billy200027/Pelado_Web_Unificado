# Inventario y decisiones de integración

## Lectura e inventario

Se leyó completamente el TXT incluido en el ZIP, el HTML, variables, estilos, JavaScript, logotipo y README de 01, y el HTML, CSS, JavaScript, README y prototype-meta de 02. No hay un Excel real de muestra dentro de este ZIP. `prototype-meta.json` describe un archivo de 58 filas, pero no contiene sus datos. Las muestras de pruebas se generaron explícitamente como datos sintéticos.

| Fuente | Aporte | Tratamiento final |
|---|---|---|
| 01/index.html | Splash, shell, barra, drawer, modal | Estructura conservada; selector integrado de dos accesos |
| 01/css/variables.css | Paleta, tipografía, radios y sombras | Copia sin cambios |
| 01/css/style.css | Todos los componentes y responsive | Contenido original intacto al principio; ampliaciones al final |
| 01/js/variables.js | Valores económicos y claves v1 | Bases conservadas; adicional/horas; claves separadas para períodos |
| 01/js/app.js | Resumen, calendario, historial, ajustes, perfil y pagos | Funciones preservadas/ampliadas; cálculo puro extraído para comparación |
| 01/assets/logo.svg | Logotipo | Copia idéntica |
| 02/js/app.js | Lectura SheetJS, normalización, KPIs, barras, filtro y persistencia | Un módulo local integrado, encabezados por nombre, detalle y filtros ampliados |
| 02/index.html y CSS | Interfaz del prototipo | Funciones trasladadas a componentes del diseño maestro 01 |
| 02/exportador | HTML con JSON | Sustituido por PDF real con jsPDF y AutoTable |

## Funciones verificables conservadas

Resumen: producción después de faltas, promedio/mínimo/máximo, distribución, proyección, quincena, asistencia, conteos, libras, estado real de pagos y nueva diferencia real/proyección. Calendario: navegación, hoy, fechas, feriados, noches, libres y faltas. Historial: editar/eliminar. Ajustes: tarifas, nocturno, multiplicador, descuento por falta, quincena, bono, perfil, borrado confirmado. Perfil: modal inicial y edición. Pagos reales: importes independientes por período.

## Cambios deliberados y corregidos

1. Mes natural → período de inicio 21 y fin 20. Toda consulta, navegación, resumen, historial, pago y proyección usa la misma selección. Los números del calendario muestran también el mes para distinguir el cruce.
2. La fórmula de pelado conserva la secuencia original exacta y su truncamiento. Comparada con la función original extraída, no reescrita como expectativa de prueba, en 500 casos.
3. Se conserva el recálculo histórico con ajustes actuales y se advierte en la interfaz y README. No hay snapshot de tarifas.
4. Faltas futuras: se corrige una doble resta del código original. El conteo revisa cada fecha y la excluye una sola vez.
5. Días sin registro: conservan el comportamiento proyectable del original, pero su etiqueta es ahora Sin registro, para distinguirlos de una jornada guardada. No se suman como días efectivamente trabajados en KPIs.
6. Ajustes de perfil: el original mostraba nombre/edad en Ajustes, pero Guardar cambios no los persistía; ahora sí los guarda.
7. Historial vacío: Ver calendario abre de verdad esa vista.
8. Pagos v1: no se asignan por suposición. Se archivan con su mes original y el trabajador elige el período destino.
9. Horas: referencia 2,01/h, multiplicador feriado independiente 1 provisional, sin descansos automáticos. Cruce de medianoche explícito; >16 h pide confirmación, hasta 24 h. Son límites de validación editables en código, no reglas salariales.
10. Analizador: se conserva lectura de código/empleado/fecha/producto/talla/categoría/entrada/salida/libras/rendimiento/tarifa/pago, además de la categoría corregida. No se usan las tarifas del control diario para rellenar pagos del Excel.
11. Horarios de análisis: deduplicación exacta por trabajador/día/intervalo, y soporte de horas seriales Excel. Si el origen incluye fechas explícitas se respeta la diferencia real; si solo hay HH:MM y el fin es anterior se conserva la interpretación nocturna del prototipo. Duraciones de análisis no alteran la nómina del control diario.
12. SheetJS se empaqueta en versión 0.20.3 en lugar del CDN 0.18.5 del prototipo. jsPDF 2.5.2 y AutoTable 3.8.4 se empaquetan con licencias. No hay peticiones a CDN durante el análisis/PDF.
13. La carga anónima no está activada. Hay frontend, endpoint protegido, SQL/RLS, limpieza, configuración ejemplo y guía. El PDF no se envía.

## Límites de verificación

Se probaron cálculos, DOM, parser y generación PDF localmente. No hubo navegador visual autorizado disponible para QA de responsive ni dispositivo Android. No se desplegó Supabase, por lo que las pruebas de endpoint son simuladas y no certifican políticas SQL ni comportamiento de infraestructura real. La entrega no afirma esas verificaciones.

## Etapas guardadas

1. Fuentes originales preservadas; integración inicial guardada en un checkpoint ZIP de trabajo.
2. Control diario, migración, categorías y horas terminados.
3. Excel/PDF, dependencias locales e integración opcional terminados.
4. Pruebas, correcciones y documentación incorporadas al ZIP final.

El archivo `ORIGINALES_SHA256.txt` permite verificar los originales incluidos. El ZIP final contiene una sola aplicación integrada en 03; las carpetas 01 y 02 son únicamente fuentes de referencia inalteradas.

## Actualización confirmada por Billy (14/10/2026, después del ZIP inicial)

Los valores predeterminados ahora son 0,11 / 0,14 / 0,22. Esta decisión explícita sustituye la conservación de los valores iniciales para instalaciones nuevas, pero no sobrescribe las tarifas ya guardadas. Se agregó `pelado_price_overrides_v1` y un botón de restablecimiento. Los cambios en localStorage no se propagan a otros dispositivos; los cambios predeterminados se distribuyen publicando `variables.js`. Supabase se limita al Excel mensual original y metadatos necesarios de recepción/seguridad. Se retiró la tabla y consulta remota de tarifas. El destino solicitado es un proyecto nuevo, independiente de Cuadros_app. La publicación permanece pendiente del permiso técnico de escritura de la integración GitHub (403).

## Clasificación confirmada más reciente

Grande: 15, 16, 21 y 26. Mediano: 31, 36 y 41. Pequeño: 51. Las tallas no enumeradas se muestran Sin clasificar; no se asignan por suposición ni a la categoría adicional. Esto sustituye la regla anterior de resto grande.
