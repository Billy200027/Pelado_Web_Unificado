// Ejecutar diariamente en un servidor/cron seguro. Node >=20. Nunca publicar este entorno.
const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;
if(!url||!key)throw Error('Faltan secretos de servidor.');
const headers={apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json'};
const r=await fetch(url+'/rest/v1/pelado_uploads?delete_after=lt.'+encodeURIComponent(new Date().toISOString())+'&select=id,path&limit=100',{headers});if(!r.ok)throw Error('No se pudo consultar vencidos');
for(const row of await r.json()){
 const del=await fetch(url+'/storage/v1/object/pelado-private',{method:'DELETE',headers,body:JSON.stringify({prefixes:[row.path]})});if(!del.ok)throw Error('No se pudo eliminar '+row.id);
 const meta=await fetch(url+'/rest/v1/pelado_uploads?id=eq.'+row.id,{method:'DELETE',headers});if(!meta.ok)throw Error('No se pudo eliminar metadata '+row.id);
}
const limits=await fetch(url+'/rest/v1/pelado_upload_limits?window_start=lt.'+encodeURIComponent(new Date(Date.now()-2*86400000).toISOString()),{method:'DELETE',headers});if(!limits.ok)throw Error('No se pudieron limpiar contadores');
