-- Ejecutar en un proyecto Supabase dedicado o revisar políticas existentes.
-- No modifica registros diarios: estos permanecen exclusivamente en el navegador.

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('pelado-private','pelado-private',false,10485760,array['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-excel','text/csv'])
on conflict(id) do update set public=false,file_size_limit=10485760,allowed_mime_types=excluded.allowed_mime_types;
-- No políticas de INSERT, SELECT ni listado para anónimos.
-- El administrador se autoriza por app_metadata, nunca por user_metadata.
create policy "pelado_admin_read" on storage.objects for select to authenticated
 using(bucket_id='pelado-private' and (select auth.jwt()->'app_metadata'->>'pelado_admin')='true');
create policy "pelado_admin_delete" on storage.objects for delete to authenticated
 using(bucket_id='pelado-private' and (select auth.jwt()->'app_metadata'->>'pelado_admin')='true');

create table if not exists public.pelado_uploads (
 id uuid primary key, path text not null unique, created_at timestamptz not null default now(),
 delete_after timestamptz not null, consent_version text not null default '1'
);
alter table public.pelado_uploads enable row level security;
revoke all on public.pelado_uploads from anon, authenticated;
grant select on public.pelado_uploads to authenticated;
create policy "pelado_admin_metadata" on public.pelado_uploads for select to authenticated
 using((select auth.jwt()->'app_metadata'->>'pelado_admin')='true');

create table if not exists public.pelado_upload_limits (
 identity_hash text not null, window_start timestamptz not null,
 requests integer not null default 1, primary key(identity_hash,window_start)
);
alter table public.pelado_upload_limits enable row level security;
revoke all on public.pelado_upload_limits from public, anon, authenticated;
-- Acceso exclusivo service_role. Incremento atómico; persiste entre instancias.
create or replace function public.pelado_consume_upload(p_identity text, p_limit integer)
returns boolean language plpgsql security invoker set search_path='' as $$
declare n integer;
begin
 if p_limit<1 or p_limit>100 then return false; end if;
 insert into public.pelado_upload_limits(identity_hash,window_start,requests)
 values(p_identity,date_trunc('hour',now()),1)
 on conflict(identity_hash,window_start) do update set requests=public.pelado_upload_limits.requests+1
 returning requests into n;
 return n<=p_limit;
end; $$;
revoke all on function public.pelado_consume_upload(text,integer) from public,anon,authenticated;
grant execute on function public.pelado_consume_upload(text,integer) to service_role;
grant all on public.pelado_upload_limits,public.pelado_uploads to service_role;
