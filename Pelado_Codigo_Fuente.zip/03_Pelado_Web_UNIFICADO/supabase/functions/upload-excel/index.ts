// Deno Edge Function. Secretos solamente del entorno servidor.
const env=(key:string)=>Deno.env.get(key)||'';
const MAX=10*1024*1024;
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin')||'',allowed=env('ALLOWED_ORIGIN');
 const cors={'Access-Control-Allow-Origin':allowed,'Access-Control-Allow-Headers':'content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin'};
 const reply=(status:number,body:unknown)=>new Response(JSON.stringify(body),{status,headers:{...cors,'Content-Type':'application/json'}});
 if(!allowed||origin!==allowed)return reply(403,{error:'Origen no permitido.'});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
 if(req.method!=='POST')return reply(405,{error:'Método no admitido.'});
 const url=env('SUPABASE_URL'),secret=env('SUPABASE_SERVICE_ROLE_KEY');
 if(!url||!secret||!env('TURNSTILE_SECRET_KEY')||!env('RATE_SALT'))return reply(503,{error:'Servicio no configurado.'});
 const days=Number(env('RETENTION_DAYS')||90);if(!Number.isInteger(days)||days<1||days>365)return reply(503,{error:'Retención no configurada correctamente.'});
 const adminHeaders={apikey:secret,Authorization:`Bearer ${secret}`};
 async function consume(identity:string,limit:number){const r=await fetch(url+'/rest/v1/rpc/pelado_consume_upload',{method:'POST',headers:{...adminHeaders,'Content-Type':'application/json'},body:JSON.stringify({p_identity:identity,p_limit:limit})});return r.ok&&(await r.json())===true;}
 try{
  // Gateway debe sobrescribir la IP de origen; no confiar en encabezados de un proxy propio sin sanitizar.
  const ip=(req.headers.get('x-forwarded-for')||'unknown').split(',')[0].trim();
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(env('RATE_SALT')+ip));
  const hash=Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join('');
  if(!await consume('global',100)||!await consume(hash,5))return reply(429,{error:'Límite de envíos alcanzado. Intenta más tarde.'});
  if(!req.headers.get('content-type')?.startsWith('multipart/form-data'))return reply(415,{error:'Se requiere un formulario con archivo.'});
  const length=Number(req.headers.get('content-length')||0);if(length>MAX+65536)return reply(413,{error:'Archivo demasiado grande.'});
  // Acotar también transferencias sin Content-Length antes de parsear el multipart.
  const reader=req.body?.getReader();if(!reader)return reply(400,{error:'Falta archivo.'});
  const chunks:Uint8Array[]=[];let total=0;while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>MAX+65536){await reader.cancel();return reply(413,{error:'Máximo 10 MB.'});}chunks.push(value);}
  const body=new Uint8Array(total);let offset=0;for(const c of chunks){body.set(c,offset);offset+=c.length;}
  const form=await new Request(req.url,{method:'POST',headers:{'content-type':req.headers.get('content-type')!},body}).formData();
  const file=form.get('file');if(form.get('consent')!=='yes')return reply(400,{error:'Falta consentimiento.'});
  if(!(file instanceof File)||!file.size||file.size>MAX)return reply(400,{error:'Archivo vacío o superior a 10 MB.'});
  const ext=file.name.split('.').pop()?.toLowerCase();
  const mime:Record<string,string>={xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',xls:'application/vnd.ms-excel',csv:'text/csv'};
  if(!ext||!mime[ext])return reply(415,{error:'Extensión no permitida.'});
  const accepted:Record<string,string[]>={xlsx:[mime.xlsx,'application/octet-stream',''],xls:[mime.xls,'application/octet-stream',''],csv:['text/csv','application/csv','text/plain',mime.xls,'application/octet-stream','']};
  if(!accepted[ext].includes(file.type))return reply(415,{error:'Tipo MIME no admitido.'});
  const bytes=new Uint8Array(await file.arrayBuffer());
  if(ext==='xlsx'&&!(bytes[0]===0x50&&bytes[1]===0x4b))return reply(415,{error:'Firma XLSX inválida.'});
  if(ext==='xls'&&![0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1].every((b,i)=>bytes[i]===b))return reply(415,{error:'Firma XLS inválida.'});
  if(ext==='csv'){try{new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{return reply(415,{error:'CSV debe estar codificado en UTF-8.'});}if(bytes.includes(0))return reply(415,{error:'CSV binario no permitido.'});}
  const token=String(form.get('captcha')||'');if(!token)return reply(400,{error:'Falta verificación antiabuso.'});
  const verify=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',body:new URLSearchParams({secret:env('TURNSTILE_SECRET_KEY'),response:token})});
  const captcha=await verify.json();if(!captcha.success||captcha.hostname!==new URL(allowed).hostname)return reply(403,{error:'Verificación antiabuso inválida.'});
  const id=crypto.randomUUID(),path=`${new Date().toISOString().slice(0,7)}/${id}.${ext}`;
  const stored=await fetch(`${url}/storage/v1/object/pelado-private/${path}`,{method:'POST',headers:{...adminHeaders,'Content-Type':mime[ext],'x-upsert':'false'},body:bytes});
  if(!stored.ok)return reply(502,{error:'No se pudo almacenar el documento.'});
  const recorded=await fetch(url+'/rest/v1/pelado_uploads',{method:'POST',headers:{...adminHeaders,'Content-Type':'application/json'},body:JSON.stringify({id,path,delete_after:new Date(Date.now()+days*86400000).toISOString(),consent_version:'1'})});
  if(!recorded.ok){await fetch(url+'/storage/v1/object/pelado-private',{method:'DELETE',headers:{...adminHeaders,'Content-Type':'application/json'},body:JSON.stringify({prefixes:[path]})});return reply(502,{error:'No se pudo registrar la recepción. Reintenta más tarde.'});}
  return reply(201,{id});
 }catch{return reply(500,{error:'No se pudo completar el envío.'});}
});
